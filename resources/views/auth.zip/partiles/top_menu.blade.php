<div class="row navbar-fixed-top hidden-sm hidden-xs">
    <div class="row header1" style="background:#fdd670;">
      <div class="padding0" style="padding-left:20px; padding-right:20px;">
        <div class="col-md-2 col-xs-3 header2" style="padding-left:10px;"> <a href="{{ route('index') }}"><img style="height:40px; width:195px;" class="img-responsive" src="http://sundarbanbd.com/SAIFUL_DEMO/POPY_BAZAR/uploads/1550983445.png" title="" alt=""/></a> </div>
        <div class="col-md-7 col-xs-8" style="padding-top:12px;">
          <div class="input-group">
            <input type="text" class="search_field header_search_keyup" style="height:40px; font-size:14px; padding-right:10px; border-top-left-radius: 4px; border-bottom-left-radius:4px;" name="header_search_value" id="header_search_value" placeholder="Search for product name..">
            <span class="input-group-btn">
            <button class="search_button" type="submit" name="Submit" style="height:40px; background:#FFFFFF; border-top-right-radius:4px; border-bottom-right-radius: 4px;" value="Search"><i style="background:#FFFFFF; color:#000000;" class="fa fa-search" aria-hidden="true"></i></button>
            </span> </div>
        </div>
        <div class="col-md-1" style="font-size:11px; padding-top:25px; border-right:1px #ecc766 solid; border-left:1px #ecc766 solid;  padding-bottom:10px; text-align:center;"><a style="color:#000000;" href="#">Help Us ?</a></div>
        <div class="col-md-1" style="font-size:11px; padding-top:25px; background:#fdd670; padding-bottom:14px; color:#000000; font-weight:bold; padding-left:30px;"> <a language-id="English" class="language_click"  style="color:#000000;" href="#" >Contact Us </a></div>
        <div class="col-md-1" style="font-size:11px; padding-top:25px; background:#ff686e; padding-bottom:18px; color:#FFFFFF; font-weight:bold; padding-left:20px;">
          <div class="btn-group show-on-hover"> <a style="color:#FFFFFF;" href="{{ route('login') }}">Sign In</a> </div>
        </div>
      </div>
    </div>
  </div>
  
  <div class="row navbar-fixed-top hidden-md hidden-lg" style="padding-bottom:5px; padding-left:10px; padding-right:10px;">
    <nav id='cssmenu'>
      <div class="logo"><a href="{{ route('index') }}"><img style="height:40px; width:195px;" class="img-responsive" src="http://sundarbanbd.com/SAIFUL_DEMO/POPY_BAZAR/uploads/1550983445.png" title="" alt=""/></a></div>
      <div id="head-mobile"></div>
      <div style="color:#000000;" class="button"></div>
      <ul style="overflow: auto; height: 200px;">
        <li> <a style="background:#FFFFFF; font-weight:normal; font-size:14px; color:#000000; padding-top:10px;" href="http://sundarbanbd.com/SAIFUL_DEMO/POPY_BAZAR/Offer.html"> Offer
          <input style="background:#FFFFFF; border:1px #fdd670 solid; padding-top:1px; padding-left:5px; padding-right:5px; padding-bottom:1px;" name="" value="5" type="button">
          </a> </li>
        <li> <a style="background:#FFFFFF; font-weight:normal; font-size:14px; color:#000000; padding-top:10px;" href="http://sundarbanbd.com/SAIFUL_DEMO/POPY_BAZAR/home/product_request.html"> Product Request </a> </li>
        <li style="background:#FFFFFF; color:#000000;"><a style="background:#FFFFFF; color:#000000;" href='#' category-id="24" class="category_click">Category</a>
          <ul>
            <li style="background:#FFFFFF; color:#000000;"><a style="background:#FFFFFF; color:#000000;" subcategory-id="15" class="subcategory_click"  href="#">Sub Category </a></li>
          </ul>
        </li>
        <li style="background:#FFFFFF; color:#000000;"><a style="background:#FFFFFF; color:#000000;" href='http://sundarbanbd.com/SAIFUL_DEMO/POPY_BAZAR/Sign_in.html'>Sign In</a></li>
        <li style="background:#FFFFFF; color:#000000;"><a style="background:#FFFFFF; color:#000000;" href='http://sundarbanbd.com/SAIFUL_DEMO/POPY_BAZAR/Sing_up.html'>Sign Up</a></li>
      </ul>
    </nav>
    <div class="input-group" style="">
      <input type="text" class="search_field header_search_keyup" style="height:40px; font-size:14px; padding-right:10px; border-top-left-radius: 4px; border-bottom-left-radius:4px; border-top:#fdd670 2px solid; border-left:#fdd670 2px solid; border-bottom:#fdd670 2px solid;" name="header_search_value" id="header_search_value" placeholder="">
      <span class="input-group-btn">
      <button class="search_button" type="submit" name="Submit" style="height:40px; background:#FFFFFF; border-top-right-radius:4px; border-bottom-right-radius: 4px; border-top:#fdd670 2px solid; border-right:#fdd670 2px solid; border-bottom:#fdd670 2px solid;" value="Search"><i style="background:#FFFFFF; color:#000000;" class="fa fa-search" aria-hidden="true"></i></button>
      </span> </div>
  </div>