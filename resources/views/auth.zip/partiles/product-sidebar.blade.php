<div class="row">
      <!-- uncomment code for absolute positioning tweek see top comment in css -->
      <div class="absolute-wrapper"> </div>
      <!-- Menu -->
      <div class="side-menu">
        <nav class="navbar navbar-default left_menu_back" role="navigation">
          <!-- Main Menu -->
          <div class="side-menu-container">
            <ul class="nav navbar-nav">
              <li class="active"><a class="hover_color" href="#"><span class="glyphicon glyphicon-dashboard"></span> Dashboard</a></li>
              <li><a class="hover_color" href="#"><span class="glyphicon glyphicon-plane"></span> Active Link</a></li>
              <li><a class="hover_color" href="#"><span class="glyphicon glyphicon-cloud"></span> Link</a></li>
              <li><a class="hover_color" href="#"><span class="glyphicon glyphicon-signal"></span> Link</a></li>
            </ul>
          </div>
          <!-- /.navbar-collapse -->
        </nav>
      </div>
    </div>