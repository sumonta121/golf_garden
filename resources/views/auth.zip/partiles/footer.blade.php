<footer class="pull-left footer">
  <div style="padding-top:20px;"></div>
    <div class="row fotter_back">
    Copyright &COPY; 2019 Saiful Islam
    </div>
  </footer>