<script type="text/javascript" src="{{ asset('admin_resorce/js/jquery-3.2.1.min.js')}}"></script>
<script type="text/javascript" src="{{ asset('admin_resorce/js/bootstrap.min.js')}}"></script>
<script type="text/javascript" src="{{ asset('admin_resorce/js/jquery.slimscroll.js')}}"></script>
<script type="text/javascript" src="{{ asset('admin_resorce/js/select2.min.js')}}"></script>
<script type="text/javascript" src="{{ asset('admin_resorce/js/moment.min.js')}}"></script>
<script type="text/javascript" src="{{ asset('admin_resorce/js/bootstrap-datetimepicker.min.js')}}"></script>
<script type="text/javascript" src="{{ asset('admin_resorce/js/app.js')}}"></script>