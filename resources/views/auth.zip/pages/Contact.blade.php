@extends('layouts.master')

@section('content')
<div class="col-md-10 content">
<h2>Contact Pages</h2>
  	<p>At any time to contact us, please call 01794700991. 
The message in the form below, you can according to your ease. A representative from us within 48 hours, you will get the message</p>
  </div>
@endsection('')
